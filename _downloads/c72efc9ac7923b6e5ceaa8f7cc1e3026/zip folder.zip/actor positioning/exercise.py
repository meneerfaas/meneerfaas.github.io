from pygame import Rect
from pgzero.actor import Actor
import time

class Exercise:

    @staticmethod
    def distance(p1, p2):
        return ((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)**0.5

    def __init__(self):

        self._question = ''
        self._toggles_visible = []
        self._toggles_on = []
        self._anchors_visible = []
        self._starting_position = (0, 0)
        self._anchor = ('center', 'center')
        self._conditions = []
        self._attempts = 0
        self._start_time = None
        self._end_time = None
        self._time_needed = None
        self._params = {}

    @property
    def question(self):
        return self._question

    @question.setter
    def question(self, val):
        self._question = val

    @property
    def toggles_visible(self):
        return self._toggles_visible

    @toggles_visible.setter
    def toggles_visible(self, val):
        self._toggles_visible = val

    @property
    def toggles_on(self):
        return self._toggles_on

    @toggles_on.setter
    def toggles_on(self, val):
        self._toggles_on = val

    @property
    def anchors_visible(self):
        return self._anchors_visible

    @anchors_visible.setter
    def anchors_visible(self, val):
        self._anchors_visible = val

    @property
    def starting_position(self):
        return self._starting_position

    @starting_position.setter
    def starting_position(self, val):
        self._starting_position = val

    @property
    def anchor(self):
        return self._anchor

    @anchor.setter
    def anchor(self, val):
        self._anchor = val

    @property
    def attempts(self):
        return self._attempts

    @attempts.setter
    def attempts(self, val):
        self._attempts = val

    @property
    def time_needed(self):
        return self._time_needed

    @time_needed.setter
    def time_needed(self, val):
        self._time_needed = val

    @property
    def params(self):
        return self._params

    def add_condition(self, c):
        self._conditions.append(c)

    def is_passed(self, actor):
        return all(condition(actor, self) for condition in self._conditions)

    def start(self):
        self._start_time = time.time()

    def finish(self):
        self._end_time = time.time()
        self._time_needed = self._end_time - self._start_time
