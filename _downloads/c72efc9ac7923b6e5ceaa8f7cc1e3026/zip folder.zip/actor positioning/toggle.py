import pygame
from pgzero.actor import Actor

class Toggle(Actor):

    vspace = 10
    toggle_disabled_col = 'lightgray'

    def __init__(self, image_on, image_off, label, pos=None, anchor=None, value=False, fontname=None, fontsize=24, fontcolor='white'):
        self._image_on = image_on
        self._image_off = image_off
        self._label = label
        self._value = value

        self._fontname = fontname
        self._fontsize = fontsize
        self._fontcolor = fontcolor
        self.__label_font = pygame.font.SysFont(fontname, fontsize)
        self.__color = fontcolor

        self._enabled = True
        self._visible = True

        if value:
            super().__init__(image_on, pos, anchor)
        else:
            super().__init__(image_off, pos, anchor)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, val):
        self._value = val
        if val:
            self.image = self._image_on
        else:
            self.image = self._image_off

    @property
    def label(self):
        return self._label

    @label.setter
    def label(self, val):
        self._label = value

    @property
    def fontcolor(self):
        return self._fontcolor

    @fontcolor.setter
    def fontcolor(self, val):
        self._fontcolor = val

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, val):
        self._enabled = val
        if val:
            self.__color = self._fontcolor
        else:
            self.__color = self.toggle_disabled_col
            self.value = False

    @property
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, val):
        self._visible = val
        if not val:
            self.width = self.height = 0

    @property
    def rect(self):
        if self._visible:
            return pygame.Rect(self.topleft, (self.width, self.height))
        else:
            return None

    def toggle(self):
        if not self.enabled:
            return
        if self.value:
            self.value = False
        else:
            self.value = True

    def _update_pos(self):
        super()._update_pos()
        if self._visible:
            self.width = self.width + self.__label_font.size(self._label)[0] + self.vspace
        else:
            self.width = self.height = 0

    def draw(self, screen):
        if not self._visible:
            return
        self._update_pos()
        super().draw()
        screen.draw.text(self._label, midright = self.midright, fontname = self._fontname, fontsize = self._fontsize, color = self.__color)
