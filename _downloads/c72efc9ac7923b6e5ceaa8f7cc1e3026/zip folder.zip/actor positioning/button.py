from pygame import Rect

class Button:
    shadow_offset = 3

    def __init__(self, label, rect, shadowed = True, fontname = None, fontsize = None, fontcolor = 'black', color = 'lightgray', shadow = 'darkgray'):

        self._label = label
        self._rect = rect
        self._shadowed = shadowed
        self._fontname = fontname
        self._fontsize = fontsize
        self._fontcolor = fontcolor
        self._color = color
        self._shadow_color = shadow
        self._pressed = False

    @property
    def topleft(self):
        return self._rect.topleft

    @topleft.setter
    def topleft(self, val):
        self._rect.topleft = val

    @property
    def midtop(self):
        return self._rect.midtop

    @midtop.setter
    def midtop(self, val):
        self._rect.midtop = val

    @property
    def topright(self):
        return self._rect.topright

    @topright.setter
    def topright(self, val):
        self._rect.topright = val

    @property
    def midleft(self):
        return self._rect.midleft

    @midleft.setter
    def midleft(self, val):
        self._rect.midleft = val

    @property
    def center(self):
        return self._rect.center

    @center.setter
    def center(self, val):
        self._rect.center = val

    @property
    def midright(self):
        return self._rect.midright

    @midright.setter
    def midright(self, val):
        self._rect.midright = val

    @property
    def bottomleft(self):
        return self._rect.bottomleft

    @bottomleft.setter
    def bottomleft(self, val):
        self._rect.bottomleft = val

    @property
    def midbottom(self):
        return self._rect.midbottom

    @midbottom.setter
    def midbottom(self, val):
        self._rect.midbottom = val

    @property
    def bottomright(self):
        return self._rect.bottomright

    @bottomright.setter
    def bottomright(self, val):
        self._rect.bottomright = val

    @property
    def width(self):
        return self._rect.width

    @width.setter
    def width(self, val):
        self._rect.width = val

    @property
    def height(self):
        return self._rect.height

    @height.setter
    def height(self, val):
        self._rect.height = val

    @property
    def size(self):
        return self._rect.size

    @size.setter
    def size(self, val):
        self._rect.size = val
		
    @property
    def x(self):
        return self._rect.x

    @x.setter
    def x(self, val):
        self._rect.x = val
				
    @property
    def y(self):
        return self._rect.y

    @y.setter
    def y(self, val):
        self._rect.y = val
		
    @property
    def top(self):
        return self._rect.top

    @top.setter
    def top(self, val):
        self._rect.top = val		

    @property
    def left(self):
        return self._rect.left

    @left.setter
    def left(self, val):
        self._rect.left = val
				
    @property
    def bottom(self):
        return self._rect.bottom

    @bottom.setter
    def bottom(self, val):
        self._rect.bottom = val
				
    @property
    def right(self):
        return self._rect.right

    @right.setter
    def right(self, val):
        self._rect.right = val
				
    @property
    def w(self):
        return self._rect.w

    @w.setter
    def w(self, val):
        self._rect.w = val
				
    @property
    def h(self):
        return self._rect.h

    @h.setter
    def h(self, val):
        self._rect.h = val

    @property
    def label(self):
        return self._label

    @label.setter
    def label(self, val):
        self._label = val
		
    @property
    def fontsize(self):
        return self._fontsize

    @fontsize.setter
    def fontsize(self, val):
        self._fontsize = val
		
    @property
    def fontname(self):
        return self._fontname

    @fontname.setter
    def fontname(self, val):
        self._fontname = val

    @property
    def fontcolor(self):
        return self._fontcolor

    @fontcolor.setter
    def fontcolor(self, val):
        self._fontcolor = val
				
    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, val):
        self._color = val
				
    @property
    def shadow_color(self):
        return self._shadow_color

    @shadow_color.setter
    def shadow_color(self, val):
        self._shadow_color = val

    @property
    def shadowed(self):
        return self._shadowed

    @shadowed.setter
    def shadowed(self, val):
        self._shadowed = val

    @property
    def rect(self):
        return self._rect

    @property
    def pressed(self):
        return self._pressed

    @pressed.setter
    def pressed(self, val):
        self._pressed = val

    def draw(self, screen):
        if self._shadowed:
            buttonrect = self._rect.inflate(-self.shadow_offset, -self.shadow_offset)
            shadowrect = buttonrect.move(self.shadow_offset, self.shadow_offset)
            if self._pressed:
                buttonrect.topleft = shadowrect.topleft
            screen.draw.filled_rect(shadowrect, self._shadow_color)
            screen.draw.filled_rect(buttonrect, self._color)
        else:
            buttonrect = self._rect.copy()
            screen.draw.filled_rect(buttonrect, self._color)
            if self._pressed:
                screen.draw.rect(buttonrect, self._shadow_color)
        if self._fontsize == None:
            textrect = buttonrect.inflate(-10, -10)
            screen.draw.textbox(self._label, textrect, fontname = self._fontname, color = self._fontcolor, align = 'center')
        else:
            screen.draw.text(self._label, center = buttonrect.center, fontname = self._fontname, fontsize = self._fontsize, color = self._fontcolor, align = 'center')

WIDTH = 400
HEIGHT = 300

b = Button('Test', Rect((10, 10), (100, 50)))

def on_mouse_down(pos):
    if b.rect.collidepoint(pos):
        b.pressed = True

def on_mouse_up(pos):
    b.pressed = False

def draw():
    screen.clear()
    b.draw(screen)
