import pygame
from random import randint, choice
from toggle import *
from button import *
from exercise import *

# Vensterinstellingen
WIDTH = 850
HEIGHT = 480
TITLE = 'Actor positioning'

WINDOW_ORIGIN = (350, 150)
WINDOW_WIDTH = 400
WINDOW_HEIGHT = 200
GRID_COLOR = (200, 200, 0)

ANCHOR_MIRROR = {
    'topleft'       :   'bottomright',
    'midtop'        :   'midbottom',
    'topright'      :   'bottomleft',
    'midleft'       :   'midright',
    'center'        :   'center',
    'midright'      :   'midleft',
    'bottomleft'    :   'topright',
    'midbottom'     :   'midtop',
    'bottomright'   :   'topleft'
}
ALL_ANCHORS = ['topleft', 'midtop', 'topright', 'midleft', 'center', 'midright', 'bottomleft', 'midbottom', 'bottomright']

coords_font_name = 'segoeuib'
ui_font_name = 'segoeui'

toggle_col = (0, 0, 64)

left_panel_width = 250
left_panel = Rect((0, 0), (left_panel_width, HEIGHT))
left_panel_padding = 10
right_panel = Rect((left_panel_width, 0), (WIDTH - left_panel_width, HEIGHT))

settings_rect = Rect((0, 0), (0, 0))

alien = Actor('alien_pink', (WIDTH / 2, HEIGHT / 2))
alien.anchors = ['topleft', 'midtop', 'topright', 'midleft', 'center', 'midright', 'bottomleft', 'midbottom', 'bottomright']

current_exercise = 1
checkmark_wrong = Actor('check_wrong')
checkmark_right = Actor('check_right')
checkmark_wrong.visible = False
checkmark_right.visible = False

grid_toggle = Toggle('toggle_on_blue', 'toggle_off', 'Toon grid', fontname = ui_font_name, fontsize = 16, fontcolor = toggle_col)
grid_toggle.topleft = (10, 10)
bounding_box_toggle = Toggle('toggle_on_blue', 'toggle_off', 'Toon bounding box', fontname = ui_font_name, fontsize = 16, fontcolor = toggle_col)
bounding_box_toggle.topleft = (10, 40)
dimensions_toggle = Toggle('toggle_on_blue', 'toggle_off', 'Toon afmetingen', fontname = ui_font_name, fontsize = 16, fontcolor = toggle_col)
dimensions_toggle.topleft = (10, 70)
anchor_points_toggle = Toggle('toggle_on_blue', 'toggle_off', 'Toon anchor points', fontname = ui_font_name, fontsize = 16, fontcolor = toggle_col)
anchor_points_toggle.topleft = (10, 100)
coordinates_toggle = Toggle('toggle_on_blue', 'toggle_off', 'Toon coordinaten', fontname = ui_font_name, fontsize = 16, fontcolor = toggle_col)
coordinates_toggle.topleft = (10, 130)
toggles = [grid_toggle, bounding_box_toggle, dimensions_toggle, anchor_points_toggle, coordinates_toggle]

checkbutton = Button('Check', Rect((0, 0), (50, 50)), fontname = ui_font_name, fontsize = 24)

finished = False
started = False

ex_01 = Exercise()
ex_01.params["x"] = randint(5, 30) * 10
ex_01.params["y"] = randint(5, 10) * 10
ex_01.question = f'Positioneer de alien zodat geldt:\nalien.topleft = ({ex_01.params["x"]}, {ex_01.params["y"]}).'
ex_01.question += '\n\nJe kunt de alien met de muis verslepen of de pijltjestoetsen gebruiken.'
ex_01.toggles_visible = [bounding_box_toggle, anchor_points_toggle, coordinates_toggle]
ex_01.toggles_on = [bounding_box_toggle, anchor_points_toggle, coordinates_toggle]
ex_01.anchors_visible = ['topleft']
ex_01.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
ex_01.add_condition(lambda actor, e: Exercise.distance(actor.topleft, real_coords((e.params['x'], e.params['y']))) <= 0)

ex_05 = Exercise()
ex_05.params["x"] = WINDOW_WIDTH
ex_05.params["side"] = choice(['left', 'right'])
ex_05.question = f'Positioneer de alien zodat geldt:\nalien.{ex_05.params["side"]} = WIDTH.'
ex_05.toggles_visible = [bounding_box_toggle]
ex_05.toggles_on = [bounding_box_toggle]
ex_05.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
if ex_05.params["side"] == 'left':
    ex_05.add_condition(lambda actor, e: abs(actor.left - (e.params['x'] + WINDOW_ORIGIN[0])) <= 5)
elif ex_05.params["side"] == 'right':
    ex_05.add_condition(lambda actor, e: abs(actor.right - (e.params['x'] + WINDOW_ORIGIN[0])) <= 5)

ex_06 = Exercise()
ex_06.params["x"] = 0
ex_06.params["side"] = choice(['left', 'right'])
ex_06.question = f'Positioneer de alien zodat geldt:\nalien.{ex_06.params["side"]} = 0.'
ex_06.toggles_visible = [bounding_box_toggle]
ex_06.toggles_on = [bounding_box_toggle]
ex_06.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
if ex_06.params["side"] == 'left':
    ex_06.add_condition(lambda actor, e: abs(actor.left - (e.params['x'] + WINDOW_ORIGIN[0])) <= 5)
elif ex_06.params["side"] == 'right':
    ex_06.add_condition(lambda actor, e: abs(actor.right - (e.params['x'] + WINDOW_ORIGIN[0])) <= 5)

ex_07 = Exercise()
ex_07.params["x"] = choice([0, WINDOW_WIDTH])
if ex_07.params["x"] == WINDOW_WIDTH:
    t = 'WIDTH'
else:
    t = str(ex_07.params["x"])
ex_07.question = f'Positioneer de alien zodat geldt:\nalien.x = {t}.'
ex_07.toggles_visible = [bounding_box_toggle, anchor_points_toggle]
ex_07.toggles_on = [anchor_points_toggle]
ex_07.anchors_visible = ALL_ANCHORS
ex_07.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
ex_07.add_condition(lambda actor, e: abs(actor.x - (e.params['x'] + WINDOW_ORIGIN[0])) <= 5)

ex_08 = Exercise()
ex_08.params["y"] = choice([0, WINDOW_HEIGHT])
ex_08.params["side"] = choice(['top', 'bottom'])
if ex_08.params["y"] == WINDOW_HEIGHT:
    t = 'HEIGHT'
else:
    t = str(ex_08.params["y"])
ex_08.question = f'Positioneer de alien zodat geldt:\nalien.{ex_08.params["side"]} = {t}.'
ex_08.toggles_visible = [bounding_box_toggle]
ex_08.toggles_on = [bounding_box_toggle]
ex_08.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
if ex_08.params["side"] == 'top':
    ex_08.add_condition(lambda actor, e: abs(actor.top - (e.params['y'] + WINDOW_ORIGIN[1])) <= 5)
elif ex_08.params["side"] == 'bottom':
    ex_08.add_condition(lambda actor, e: abs(actor.bottom - (e.params['y'] + WINDOW_ORIGIN[1])) <= 5)

ex_02 = Exercise()
ex_02.params["x"] = randint(10, 35) * 10
ex_02.params["y"] = randint(10, 15) * 10
ex_02.question = f'Positioneer de alien zodat geldt:\nalien.bottomright = ({ex_02.params["x"]}, {ex_02.params["y"]}).'
ex_02.toggles_visible = [bounding_box_toggle, anchor_points_toggle, coordinates_toggle]
ex_02.toggles_on = [bounding_box_toggle, anchor_points_toggle, coordinates_toggle]
ex_02.anchors_visible = ['topleft', 'topright', 'bottomleft', 'bottomright']
ex_02.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
ex_02.add_condition(lambda actor, e: Exercise.distance(actor.bottomright, real_coords((e.params['x'], e.params['y']))) <= 0)

ex_03 = Exercise()
ex_03.params["x"] = randint(1, 7) * 50
ex_03.params["y"] = randint(1, 2) * 50
ex_03.question = f'Positioneer de alien zodat geldt:\nalien.midtop = ({ex_03.params["x"]}, {ex_03.params["y"]}).'
ex_03.question += '\n\nJe ziet nu niet de coordinaten. Kijk naar de afmetingen van het Game Window en gebruik het grid. Je mag er een klein beetje naast zitten.'
ex_03.toggles_visible = [grid_toggle, bounding_box_toggle, anchor_points_toggle]
ex_03.toggles_on = [grid_toggle, bounding_box_toggle, anchor_points_toggle]
ex_03.anchors_visible = ['midtop']
ex_03.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
ex_03.add_condition(lambda actor, e: Exercise.distance(actor.midtop, real_coords((ex_03.params["x"], ex_03.params["y"]))) <= 5)

ex_04 = Exercise()
ex_04.params["x"] = randint(1, 4) * 100
ex_04.question = f'Positioneer de alien zodat geldt:\nalien.left < {ex_04.params["x"]} en alien.right > {ex_04.params["x"]}.'
ex_04.toggles_visible = [grid_toggle, bounding_box_toggle]
ex_04.toggles_on = [grid_toggle]
if ex_04.params['x'] >= 200:
    ex_04.starting_position = (0, 0)
    ex_04.anchor = ('left', 'top')
else:
    ex_04.starting_position = (WINDOW_WIDTH, WINDOW_HEIGHT)
    ex_04.anchor = ('right', 'bottom')
ex_04.add_condition(lambda actor, e: actor.right > (e.params["x"] + WINDOW_ORIGIN[0]))
ex_04.add_condition(lambda actor, e: actor.left < (e.params["x"] + WINDOW_ORIGIN[0]))

ex_09 = Exercise()
ex_09.params["y"] = randint(0, 2) * 100
ex_09.question = f'Positioneer de alien zodat geldt:\nalien.top < {ex_09.params["y"]} en alien.bottom > {ex_09.params["y"]}.'
ex_09.toggles_visible = [grid_toggle, bounding_box_toggle]
ex_09.toggles_on = [grid_toggle]
if ex_09.params['y'] >= 100:
    ex_09.starting_position = (0, 0)
    ex_09.anchor = ('left', 'top')
else:
    ex_09.starting_position = (WINDOW_WIDTH, WINDOW_HEIGHT)
    ex_09.anchor = ('right', 'bottom')
ex_09.add_condition(lambda actor, e: actor.bottom > (e.params["y"] + WINDOW_ORIGIN[1]))
ex_09.add_condition(lambda actor, e: actor.top < (e.params["y"] + WINDOW_ORIGIN[1]))

ex_10 = Exercise()
ex_10.params["x"] = randint(1, 7) * 50
ex_10.params["y"] = randint(1, 2) * 50
ex_10.question = f'Positioneer de alien zodat geldt:\nalien.bottomleft = ({ex_10.params["x"]}, {ex_10.params["y"]}).'
ex_10.toggles_visible = [grid_toggle, bounding_box_toggle, anchor_points_toggle]
ex_10.toggles_on = [grid_toggle, bounding_box_toggle]
ex_10.anchors_visible = ALL_ANCHORS
ex_10.starting_position = (WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2)
ex_10.add_condition(lambda actor, e: Exercise.distance(actor.bottomleft, real_coords((ex_10.params["x"], ex_10.params["y"]))) <= 5)

exercises = [ex_01, ex_02, ex_03, ex_10, ex_04, ex_09, ex_05, ex_06, ex_07, ex_08]

################################
# INIT FUNCTIONS
################################

def hide_all_toggles():
    for t in toggles:
        t.visible = False

def show_all_anchors():
    alien.anchors = ['topleft', 'midtop', 'topright', 'midleft', 'center', 'midright', 'bottomleft', 'midbottom', 'bottomright']

def init_exercise(n):
    e = exercises[n - 1]
    alien.anchor = e.anchor
    alien.pos = real_coords(e.starting_position)
    alien.anchors = e.anchors_visible
    hide_all_toggles()
    for t in toggles:
        t.value = False     # Reset all toggles
    for t in e.toggles_visible:
        t.visible = True
    for t in e.toggles_on:
        t.value = True
    e.start()

################################
# LAYOUT FUNCTIONS
################################

def layout_toggles():
    global settings_rect
    active_toggles = [t for t in toggles if t.visible == True]
    if len(active_toggles) == 0:
        return
    for index, t in enumerate(active_toggles):
        t.topleft = (left_panel_padding, 10 + 30 * index)
    settings_rect = active_toggles[0].rect.copy()
    settings_rect.unionall_ip([t.rect for t in active_toggles])
    dimensions_toggle.enabled = bounding_box_toggle.value
    coordinates_toggle.enabled = anchor_points_toggle.value

def layout_checkbutton():
    checkbutton.width = left_panel_width - 2 * left_panel_padding
    checkbutton.height = 40
    checkbutton.bottomleft = (left_panel_padding, left_panel.bottom - left_panel_padding)
    checkmark_right.center = checkbutton.topright
    checkmark_wrong.center = checkbutton.topright

################################
# DRAWING FUNCTIONS
################################

def draw_bounding_box(a, linecol = 'lightgray', showdims = False):
    r = Rect(a.topleft, (a.width, a.height))
    screen.draw.rect(r, linecol)
    if showdims:
        w_str = f'{a.width}'
        h_str = f'{a.height}'
        margin = 3
        screen.draw.text(w_str, midtop = (a.midbottom[0], a.midbottom[1] + margin), fontname = coords_font_name, fontsize = 14, color = linecol)
        screen.draw.text(h_str, midleft = (a.midright[0] + margin, a.midright[1]), fontname = coords_font_name, fontsize = 14, color = linecol)

def draw_label(text, pos, anchor = 'center', ftname = None, ftsize = 14, ftcolor = 'white', hspace = 0, vspace = 0):
    if anchor in ['topleft', 'midleft', 'bottomleft']:
        pos = (pos[0] + hspace, pos[1])
    elif anchor in ['topright', 'midright', 'bottomright']:
        pos = (pos[0] - hspace, pos[1])
    #if anchor in ['topleft', 'midtop', 'topright']:
    if 'top' in anchor:
        pos = (pos[0], pos[1] + vspace)
    elif 'bottom' in anchor:
        pos = (pos[0], pos[1] - vspace)

    screen.draw.text(text, **{f'{anchor}' : pos},fontname = ftname, fontsize = ftsize, color = ftcolor)

def draw_point(pos, radius, linecol, fillcol):
    linewidth = radius / 4
    screen.draw.filled_circle(pos, radius, linecol)
    screen.draw.filled_circle(pos, radius - linewidth, fillcol)

def draw_point_with_label(pos, radius, text, linecol = 'white', fillcol = 'black', anchor = 'topleft', ftname = None, ftsize = 14, ftcolor = 'white', hspace = 3, vspace = 3):
    draw_point(pos, radius, linecol, fillcol)
    draw_label(text, pos, anchor, ftname = ftname, ftsize = ftsize, ftcolor = ftcolor, hspace = hspace, vspace = vspace)

def draw_point_with_coords(pos, radius, linecol = 'white', fillcol = 'black', anchor = 'topleft', ftname = None, ftsize = 14, ftcolor = 'white', hspace = 3, vspace = 3):
    draw_point_with_label(pos, radius, f'({int(pos[0])}, {int(pos[1])})', linecol = linecol, fillcol = fillcol, anchor = anchor, ftname = ftname, ftsize = ftsize, ftcolor = ftcolor, hspace = hspace, vspace = vspace)

def draw_point_with_game_window_coords(pos, radius, linecol = 'white', fillcol = 'black', anchor = 'topleft', ftname = None, ftsize = 14, ftcolor = 'white', hspace = 3, vspace = 3):
    cpos = (pos[0] + WINDOW_ORIGIN[0], pos[1] + WINDOW_ORIGIN[1])
    draw_point_with_label(cpos, radius, f'({int(pos[0])}, {int(pos[1])})', linecol = linecol, fillcol = fillcol, anchor = anchor, ftname = ftname, ftsize = ftsize, ftcolor = ftcolor, hspace = hspace, vspace = vspace)

def draw_anchor_point(a, apoint, showcoords = False):
    radius = 5
    linecol = 'orange'
    fillcol = 'black'
    ftname = coords_font_name
    ftsize = 14
    ftcolor = 'orange'
    point = eval(f'a.{apoint}')
    tpoint = (point[0] - WINDOW_ORIGIN[0], point[1] - WINDOW_ORIGIN[1])
    anchor = ANCHOR_MIRROR[apoint]
    if showcoords:
        draw_point_with_game_window_coords(tpoint, radius, linecol = linecol, fillcol = fillcol, anchor = anchor, ftname = ftname, ftsize = ftsize, ftcolor = ftcolor, vspace = 5)
    else:
        draw_point(point, radius, linecol, fillcol)

def draw_all_anchor_points(a, showcoords = False):
    for p in alien.anchors:
        draw_anchor_point(a, p, showcoords)

def draw_game_window(pos, size, anchor = (1, 31), title = 'Game Window'):
    # dimensons of corner images: 128x31px
    cw = 128    # corner width
    ch = 31     # corner height
    tl = (pos[0] - anchor[0], pos[1] - anchor[1])
    tr = (tl[0] + size[0] + 2 - cw, tl[1])
    bl = (tl[0], tl[1] + size[1] + 1)
    br = (tr[0], bl[1])
    screen.blit('game_window_topleft', tl)
    screen.blit('game_window_topright', tr)
    screen.blit('game_window_bottomleft', bl)
    screen.blit('game_window_bottomright', br)
    screen.draw.line((tl[0] + cw, tl[1]), (tr[0], tr[1]), (183, 183, 180))
    screen.draw.filled_rect(Rect((tl[0] + cw, tl[1] + 1), (tr[0] - tl[0] - cw, ch - 1)), (243, 243, 243))
    screen.draw.line((bl[0] + cw, bl[1] + ch - 1), (br[0], br[1] + ch - 1), (183, 183, 180))
    screen.draw.line((tl[0], tl[1] + ch), (bl[0], bl[1]), (183, 183, 180))
    screen.draw.line((tr[0] + cw - 1, tr[1] + ch), (br[0] + cw - 1, br[1]), (183, 183, 180))
    screen.draw.filled_rect(Rect((tl[0] + 1, tl[1] + ch), (br[0] - bl[0] + cw - 2, br[1] - tr[1] - ch)), 'black')
    screen.draw.filled_rect(Rect((tl[0] + cw, bl[1]), (br[0] - bl[0] - cw, ch - 1)), 'black')
    screen.draw.text(title, (tl[0] + 32, tl[1] + 7), fontname = ui_font_name, fontsize = 12, color = 'black')

def draw_grid(origin, xstep, ystep, linecol = 'lightgray'):
    for x in range(origin[0], WIDTH, xstep):
        screen.draw.line((x, 0), (x, HEIGHT), linecol)
    for x in range(origin[0], 0, -xstep):
        screen.draw.line((x, 0), (x, HEIGHT), linecol)
    for y in range(origin[1], HEIGHT, ystep):
        screen.draw.line((0, y), (WIDTH, y), linecol)
    for y in range(origin[1], 0, -ystep):
        screen.draw.line((0, y), (WIDTH, y), linecol)

def draw_settings():
    layout_toggles()
    for t in toggles:
        t.draw(screen)

def draw_exercise(n):
    e = exercises[n - 1]
    pos = (left_panel_padding, settings_rect.bottom + 30)
    screen.draw.text(f'Opdracht {n}', topleft = pos, width = left_panel_width - 2 * left_panel_padding, fontname = ui_font_name, fontsize = 24, color = (0, 0, 128))
    pos = (left_panel_padding, settings_rect.bottom + 70)
    screen.draw.text(e.question, topleft = pos, width = left_panel_width - 2 * left_panel_padding, fontname = ui_font_name, fontsize = 16, color = 'black')

def draw_checkbutton():
    layout_checkbutton()
    checkbutton.draw(screen)

def draw_check_result():
    if checkmark_wrong.visible:
        checkmark_wrong.draw()
    elif checkmark_right.visible:
        checkmark_right.draw()

def draw_left_panel():
    screen.draw.filled_rect(left_panel, 'azure2')
    draw_settings()
    draw_exercise(current_exercise)
    draw_checkbutton()
    draw_check_result()

def draw_finished():
    one_attempt = len(list(filter(lambda x : x.attempts == 1, exercises)))
    attempts = sum([x.attempts for x in exercises])
    time_needed = int(sum([x.time_needed for x in exercises]))
    if time_needed < 60:
        time_needed_str = f'{time_needed:02} seconden'
    else:
        time_needed_str = f'{time_needed // 60}:{time_needed % 60:02d} minuten'
    margin = 20
    linewidth = 4
    padding = 40
    screen.draw.filled_rect(Rect((margin, margin), (WIDTH - 2 * margin, HEIGHT - 2 * margin)), (0, 0, 200))
    margin += linewidth
    screen.draw.filled_rect(Rect((margin, margin), (WIDTH - 2 * margin, HEIGHT - 2 * margin)), (224, 238, 238))
    margin += padding
    screen.draw.text('Finished', midtop = (WIDTH / 2, margin), fontname = ui_font_name, fontsize = 36, color = 'black')

    screen.draw.text('Aantal oefeningen in 1 keer goed: ', midleft = (margin, margin + 3 * padding), fontsize = 28, color = 'black')
    screen.draw.text(f'{one_attempt} van {len(exercises)} oefeningen', midright = (WIDTH - margin, margin + 3 * padding), fontsize = 28, color = 'black')

    screen.draw.text('Aantal pogingen totaal: ', midleft = (margin, margin + 4 * padding), fontsize = 28, color = 'black')
    screen.draw.text(f'{attempts} voor {len(exercises)} oefeningen', midright = (WIDTH - margin, margin + 4 * padding), fontsize = 28, color = 'black')

    screen.draw.text('Totaal benodigde tijd: ', midleft = (margin, margin + 5 * padding), fontsize = 28, color = 'black')
    screen.draw.text(time_needed_str, midright = (WIDTH - margin, margin + 5 * padding), fontsize = 28, color = 'black')

def draw_start_screen():
    margin = 20
    linewidth = 4
    padding = 40
    screen.draw.filled_rect(Rect((margin, margin), (WIDTH - 2 * margin, HEIGHT - 2 * margin)), (0, 0, 200))
    margin += linewidth
    screen.draw.filled_rect(Rect((margin, margin), (WIDTH - 2 * margin, HEIGHT - 2 * margin)), (224, 238, 238))
    margin += padding
    screen.draw.text('Welkom', midtop = (WIDTH / 2, margin), fontname = ui_font_name, fontsize = 36, color = 'black')

    info = f'Oefen het positioneren van sprites door de alien telkens op de gevraagde positie te zetten.'
    info += f'\n\nJe kunt de alien verslepen met de muis en ook de pijltjestoetsen gebruiken om preciezer te werken.'
    info += f'\n\nTotaal zijn er {len(exercises)} opdrachten.'
    screen.draw.text(info, midtop = (WIDTH / 2, margin + 3 * padding), width = WIDTH - 2 * margin, fontsize = 28, color = 'black')

    screen.draw.text(f'Klik met de muis of druk op een toets om te starten.', midbottom = (WIDTH / 2, HEIGHT - margin), fontsize = 28, color = 'black')

def draw():
    screen.fill((64, 64, 64))
    if not started:
        draw_start_screen()
        return
    if finished:
        draw_finished()
        return
    draw_game_window(WINDOW_ORIGIN, (WINDOW_WIDTH, WINDOW_HEIGHT), title = f'Game Window ({WINDOW_WIDTH} x {WINDOW_HEIGHT})')
    if grid_toggle.value:
        draw_grid(WINDOW_ORIGIN, 50, 50, GRID_COLOR)
    alien.draw()
    if bounding_box_toggle.value:
        draw_bounding_box(alien, 'lightgreen', dimensions_toggle.value)
    if anchor_points_toggle.value:
        draw_all_anchor_points(alien, coordinates_toggle.value)
    #draw_point_with_game_window_coords((0, 0), 5, linecol = 'pink', anchor = 'bottomright', ftname = coords_font_name, ftsize = 16, ftcolor = 'pink')
    draw_left_panel()

################################
# EVENT HANDLERS
################################

def hide_checkmark_wrong():
    checkmark_wrong.visible = False

def keep_in_window(a):
    margin = 5
    if a.right < left_panel_width + margin:
        a.right = left_panel_width + margin
    elif a.left > WIDTH - margin:
        a.left = WIDTH - margin
    if a.bottom < margin:
        a.bottom = margin
    elif a.top > HEIGHT - margin:
        a.bottom = HEIGHT - margin

def handle_check_or_next():
    global current_exercise, finished
    e = exercises[current_exercise - 1]
    if checkbutton.label == 'Check':
        e.attempts += 1
        if e.is_passed(alien):
            e.finish()
            checkmark_right.visible = True
            checkmark_wrong.visible = False
            if current_exercise < len(exercises):
                checkbutton.label = 'Volgende'
            else:
                checkbutton.label = 'Einde'
        else:
            checkmark_wrong.visible = True
            checkmark_right.visible = False
            clock.schedule_unique(hide_checkmark_wrong, 2)
    elif checkbutton.label == 'Volgende':
        checkmark_right.visible = False
        checkbutton.label = 'Check'
        if current_exercise < len(exercises):
            current_exercise += 1
            init_exercise(current_exercise)
    elif checkbutton.label == 'Einde':
        finished = True

def handle_start():
    global started
    started = True
    init_exercise(1)

def on_mouse_move(pos, rel, buttons):
    if not started:
        return
    if mouse.LEFT in buttons and alien.collidepoint(pos):
        alien.move_ip(rel[0], rel[1])
        keep_in_window(alien)

def on_mouse_down(pos):
    if not started:
        return
    for t in [grid_toggle, bounding_box_toggle, dimensions_toggle, anchor_points_toggle, coordinates_toggle]:
        if t.collidepoint(pos):
            t.toggle()
    if checkbutton.rect.collidepoint(pos):
        checkbutton.pressed = True

def on_mouse_up(pos):
    if not started:
        handle_start()
        return
    checkbutton.pressed = False
    if checkbutton.rect.collidepoint(pos):
        handle_check_or_next()

def on_key_down(key):
    if not started:
        handle_start()
        return
    if key == keys.UP:
        alien.y -= 1
    elif key == keys.DOWN:
        alien.y += 1
    if key == keys.LEFT:
        alien.x -= 1
    elif key == keys.RIGHT:
        alien.x += 1
    keep_in_window(alien)
    if key == keys.RETURN:
        handle_check_or_next()

################################
# UPDATE
################################

def update():
    pass

################################
# TRANSLATE COORDINATES
################################

def world_coords(pos):
    return (pos[0] - WINDOW_ORIGIN[0], pos[1] - WINDOW_ORIGIN[1])

def real_coords(pos):
    return (pos[0] + WINDOW_ORIGIN[0], pos[1] + WINDOW_ORIGIN[1])


